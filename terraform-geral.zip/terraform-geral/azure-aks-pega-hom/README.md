# AKS 

- https://docs.microsoft.com/en-us/azure/aks/kubernetes-walkthrough

## Create a resource group
```bash
az group create --name homolog-aks --location brazilsouth
```

## Create AKS cluster
```bash
az aks create --resource-group homolog-aks --name AKSCluster --node-count 1 --enable-addons monitoring --generate-ssh-keys
```

## Connect to the cluster
```bash
az aks install-cli
```

## Get Credentials 
```bash
az aks get-credentials --resource-group homolog-aks --name homolog-aks
Merged "homolog-aks" as current context in C:\Users\douglasqs\.kube\config
```

## Remove Resource Group
```bash
az group delete --name homolog-aks
```

## Kubernetes Dashboard
Make sure the Azure k8s dashboard is disabled
```bash
az aks disable-addons -g homolog-aks -n homolog-aks -a kube-dashboard
```

- https://www.replex.io/blog/how-to-install-access-and-add-heapster-metrics-to-the-kubernetes-dashboard
- https://github.com/kubernetes/dashboard
- https://github.com/kubernetes/dashboard/blob/master/docs/user/access-control/creating-sample-user.md

Installing the Dash
```bash
kubectl delete -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.0.3/aio/deploy/recommended.yaml
kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.0.3/aio/deploy/recommended.yaml
```

Creating the user to access
```yaml
vim k8s-dash-adminuser.yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: admin-user
  namespace: kubernetes-dashboard
```

Creating the clusterrole
```yaml
vim k8s-dash-clusterrole.yml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: admin-user
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: cluster-admin
subjects:
- kind: ServiceAccount
  name: admin-user
  namespace: kubernetes-dashboard
```

Applying
```bash
kubectl.exe apply -f .\k8s-dash-adminuser.yml
kubectl.exe apply -f .\k8s-dash-clusterrole.yml
```

Getting the bearer Token PS
```bash
kubectl -n kubernetes-dashboard describe secret $(kubectl -n kubernetes-dashboard get secret | sls admin-user | 
ForEach-Object { $_ -Split '\s+' } | Select -First 1)
Name:         admin-user-token-t9lgz
Namespace:    kubernetes-dashboard
Labels:       <none>
Annotations:  kubernetes.io/service-account.name: admin-user
              kubernetes.io/service-account.uid: 57e98497-9506-47e6-9c6b-1ae4890e4fd4

Type:  kubernetes.io/service-account-token

Data
====
ca.crt:     1720 bytes
namespace:  20 bytes
token:      eyJhbGciOiJSUzI1NiIsImtpZCI6Ikp2bldMVHY3OWZHUXFRdFRGUlVQSVlIN21nbnBaVWlZOE1iQUhsanBHLXcifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlcm5ldGVzLWRhc2hib2FyZCIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJhZG1pbi11c2VyLXRva2VuLXQ5bGd6Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQubmFtZSI6ImFkbWluLXVzZXIiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiI1N2U5ODQ5Ny05NTA2LTQ3ZTYtOWM2Yi0xYWU0ODkwZTRmZDQiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6a3ViZXJuZXRlcy1kYXNoYm9hcmQ6YWRtaW4tdXNlciJ9.Ecu9nZJXIFp5K8-mBikQzRuwf7pYekt4Xdtz6WpDfK7ADvfWL5YAasOx7sN8GYKabTYvsiR7mZ9A3w38KyLg-2lyJaI-t6NOAAt6HXz0Cq_yQtcWWinEf8j3WVUb0M2_ExnFzCdhOZfiox7ajRTIznTw5TjilR9JFHtm3sWkyEw874JhiQX_CRWOBMXtWG44fZQXfps3bTrxUmv1nnYCsQ0d8uca55l5uyoBrrZUuKOLe9HqsT74W4bIHoz22DBRq4L2dYKnsCsN4x9N74M9V2vyXjnrk-30rmgyeJhb462Zj5pUxCwiRXm6clFjc6sK6IFTjFebrc9mTZhl5wtMtzx8d-SyoOiinYOZxMGKS9MHkUJu0rMVonsjdxigkgB4ey1FS8rsihPfPUjmgGi4htHbTHNoOan2XFgC5keIB57t8AqQEvgpPd3CA6BsY65Ia0FSxycMfB59jAKWYQXqSPrZO1iCtpQtll3Cwj9g8HdPJnKIcDsiHjRitXJp-Z9IkNPpSqW-NlDOysQzllpqX4yyLn6X_zVW3xs2sKmPmfS_02930xzVah-qSx3_rXXqY1LE_BZZGdbqwbIpAONffy-nCkIX9GBtYdHo3HiycmZgsAlLHGkjLL_ZE1dthUggmva8wsEmJy3SeBVkisv8SPDR6LqvfCTx8-RmpStOSR4
```

Getting the bearer token Bash
```bash
kubectl -n kubernetes-dashboard describe secret $(kubectl -n kubernetes-dashboard get secret | grep admin-user | awk '{print $1}')
```


Getting the secrets
```bash
kubectl get secrets -n kubernetes-dashboard | sls admin-user
admin-user-token-t9lgz             kubernetes.io/service-account-token   3      4m51s
```

Describing the secrets
```bash
kubectl describe secret admin-user-token-t9lgz -n kubernetes-dashboard
```

Accessing the Dashboard
- http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/#/login

Use the Token we get
```
eyJhbGciOiJSUzI1NiIsImtpZCI6Ikp2bldMVHY3OWZHUXFRdFRGUlVQSVlIN21nbnBaVWlZOE1iQUhsanBHLXcifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlcm5ldGVzLWRhc2hib2FyZCIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJhZG1pbi11c2VyLXRva2VuLXQ5bGd6Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQubmFtZSI6ImFkbWluLXVzZXIiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiI1N2U5ODQ5Ny05NTA2LTQ3ZTYtOWM2Yi0xYWU0ODkwZTRmZDQiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6a3ViZXJuZXRlcy1kYXNoYm9hcmQ6YWRtaW4tdXNlciJ9.Ecu9nZJXIFp5K8-mBikQzRuwf7pYekt4Xdtz6WpDfK7ADvfWL5YAasOx7sN8GYKabTYvsiR7mZ9A3w38KyLg-2lyJaI-t6NOAAt6HXz0Cq_yQtcWWinEf8j3WVUb0M2_ExnFzCdhOZfiox7ajRTIznTw5TjilR9JFHtm3sWkyEw874JhiQX_CRWOBMXtWG44fZQXfps3bTrxUmv1nnYCsQ0d8uca55l5uyoBrrZUuKOLe9HqsT74W4bIHoz22DBRq4L2dYKnsCsN4x9N74M9V2vyXjnrk-30rmgyeJhb462Zj5pUxCwiRXm6clFjc6sK6IFTjFebrc9mTZhl5wtMtzx8d-SyoOiinYOZxMGKS9MHkUJu0rMVonsjdxigkgB4ey1FS8rsihPfPUjmgGi4htHbTHNoOan2XFgC5keIB57t8AqQEvgpPd3CA6BsY65Ia0FSxycMfB59jAKWYQXqSPrZO1iCtpQtll3Cwj9g8HdPJnKIcDsiHjRitXJp-Z9IkNPpSqW-NlDOysQzllpqX4yyLn6X_zVW3xs2sKmPmfS_02930xzVah-qSx3_rXXqY1LE_BZZGdbqwbIpAONffy-nCkIX9GBtYdHo3HiycmZgsAlLHGkjLL_ZE1dthUggmva8wsEmJy3SeBVkisv8SPDR6LqvfCTx8-RmpStOSR4
```

## 
chrome://flags/
- samesite by default cookies
- enable removing samesite=none cookies
- cookie without samesite must be secure

https://github.com/kubernetes/dashboard
https://github.com/kubernetes/dashboard/blob/master/docs/user/access-control/creating-sample-user.md

## Terraform 

https://docs.microsoft.com/en-us/azure/developer/terraform/create-k8s-cluster-with-tf-and-aks?toc=https%3A%2F%2Fdocs.microsoft.com%2Fen-us%2Fazure%2Faks%2Ftoc.json&bc=https%3A%2F%2Fdocs.microsoft.com%2Fen-us%2Fazure%2Fbread%2Ftoc.json



    "adminUsername": "azureuser",
    "ssh": {
      "publicKeys": [
        {
          "keyData": "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQC/G6WveUIXzkEVdZ4MrTE6CMPoHKTrF4vZKeR10VsZGx2kTj1O6mqVPa9ty1RQcU40SX/Vcrn4CxVZ
vtI+7SrHaTvoYXRzZy6D+jiW2GD/i5EdKxds5VwV61yO15PKX9wrvrTZu7BELKHm1RSZFUO5QztKSmZvJZ0S7QC5zHYaTZBsd+/FnTOuTjhOKCn6OfmEwq8uJ6pUvyCkp2EtrEuK8z
L128tInC8hro2oiKGHp+QCaZSsNUtb1jWe8Qzu3G2CGtOIzArPc0WK1KSDf84jA4pa7S4FLZ230S2ZOAD4teHADxyXJAA1bhKNT7m8zsr19rbCiexs+828WHCp+knNbOuNR8LRNgdH
fqD3IQpM5HFWFalBu7JW7XH7NOQYMFyEZ/7hhCKwN89tFfTe2pXu/yrPLQREELgQwkyLdNo9tYwJukzbfIJfURB3Pn/2nsvs4qwWQzcURew064lqmaVQrrgq3OGJpgVT/40Kn6XhnG
pW2IxYBoqoqMBMZf/jq1k= douglasqs@PRBNOTE058924\n"

## AKS - Pega
https://github.com/pegasystems/pega-helm-charts/blob/master/docs/Deploying-Pega-on-AKS.md
https://community.pega.com/knowledgebase/articles/client-managed-cloud/cloud/meeting-requirements-and-prerequisites
https://docs.microsoft.com/en-us/azure/aks/kubernetes-walkthrough-portal
https://docs.microsoft.com/en-us/azure/container-registry/container-registry-helm-repos
https://docs.microsoft.com/en-us/azure/aks/quickstart-helm


https://istio.io/latest/docs/setup/getting-started/
https://docs.microsoft.com/en-us/azure/aks/servicemesh-istio-install?pivots=client-operating-system-linux


{
  "appId": "56e001f2-a10e-41e5-8483-b69b5bcf4ab0",
  "displayName": "PrbAKSPegaHomolog",
  "name": "http://azure-cli-2019-04-11-00-46-05",
  "password": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
  "tenant": "502fe815-28ec-4a53-95a9-13bc724e318b"
}


[1:19 PM] Celso José Arruda Santos
    

Display name
PrbAKSPegaHomolog
Application (client) ID
159fe9f6-bbe8-47c2-b336-d0ca409da44e
Directory (tenant) ID
502fe815-28ec-4a53-95a9-13bc724e318b
Object ID
56e001f2-a10e-41e5-8483-b69b5bcf4ab

PrbAKSPegaHomolog - q3jJ6L~.4ZD-e10f42nw8IePvzR4nb6x_.


az ad sp create-for-rbac --skip-assignment --name PrbAKSPegaHomolog

az ad sp create-for-rbac --skip-assignment --name AKSHomolog

{
  "appId": "1d13edce-58ba-4caa-815b-f91d6b3c80e5",
  "displayName": "PrbAKSPegaHomolog",
  "name": "http://PrbAKSPegaHomolog",
  "password": "XOiDKY3k6Qw_BIG.tJ2jvhj0~p_EBMRoaH",
  "tenant": "502fe815-28ec-4a53-95a9-13bc724e318b"
}


az ad sp create-for-rbac --skip-assignment --name AKSHomolog
Changing "AKSHomolog" to a valid URI of "http://AKSHomolog", which is the required format used for service principal names
{
  "appId": "3782cd9a-e367-42d6-9d3f-4885758913b2",
  "displayName": "AKSHomolog",
  "name": "http://AKSHomolog",
  "password": "df401afc-19f7-43a5-9e56-610f8fa77c98",
  "tenant": "502fe815-28ec-4a53-95a9-13bc724e318b"
}


## OK
https://learn.hashicorp.com/terraform/kubernetes/provision-aks-cluster
az ad sp create-for-rbac --skip-assignment --name PrbAKSPegaHomolog
Changing "PrbAKSPegaHomolog" to a valid URI of "http://PrbAKSPegaHomolog", which is the required format used for service principal names
{
  "appId": "0ba4a576-c62f-48f7-a68b-73c3328e598a",
  "displayName": "PrbAKSPegaHomolog",
  "name": "http://PrbAKSPegaHomolog",
  "password": "7076c698-737a-456b-a8c4-ac1598141e70",
  "tenant": "502fe815-28ec-4a53-95a9-13bc724e318b"
}



az aks get-credentials --resource-group Azure_AKS --name pega-aks

kubectl create clusterrolebinding kubernetes-dashboard --clusterrole=cluster-admin --serviceaccount=kube-system:kubernetes-dashboard

az aks browse --resource-group Azure_AKS --name pega-aks


## Database
syssa@k8s-pega
jJ3xR]TTsnD-Dv97

Database name: pega-aks

## JDBC 
jdbc:sqlserver://pega-aks.database.windows.net:1433;database=pega-aks;user=syssa@pega-aks;password=jJ3xR]TTsnD-Dv97;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;

curl -LO https://storage.googleapis.com/kubernetes-release/release/$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)/bin/linux/amd64/kubectl



ewogICJjbGllbnRJZCI6ICJjZGNiMDk3Zi0zYjgxLTQzY2ItYTQ0Zi1hYzJhMmY1Mzk2ODkiLAogICJjbGllbnRTZWNyZXQiOiAiQ3Z3VmltWW5MZDY4NmN1OG5xZHNlQkY3V0c2fmFTTn5zaSIsCiAgInN1YnNjcmlwdGlvbklkIjogIjE5ZDI0ZTEwLTFkZGYtNGY3ZS05NjE1LWFiZDhkYzNiODhkMyIsCiAgInRlbmFudElkIjogIjUwMmZlODE1LTI4ZWMtNGE1My05NWE5LTEzYmM3MjRlMzE4YiIsCiAgImFjdGl2ZURpcmVjdG9yeUVuZHBvaW50VXJsIjogImh0dHBzOi8vbG9naW4ubWljcm9zb2Z0b25saW5lLmNvbSIsCiAgInJlc291cmNlTWFuYWdlckVuZHBvaW50VXJsIjogImh0dHBzOi8vbWFuYWdlbWVudC5henVyZS5jb20vIiwKICAiYWN0aXZlRGlyZWN0b3J5R3JhcGhSZXNvdXJjZUlkIjogImh0dHBzOi8vZ3JhcGgud2luZG93cy5uZXQvIiwKICAic3FsTWFuYWdlbWVudEVuZHBvaW50VXJsIjogImh0dHBzOi8vbWFuYWdlbWVudC5jb3JlLndpbmRvd3MubmV0Ojg0NDMvIiwKICAiZ2FsbGVyeUVuZHBvaW50VXJsIjogImh0dHBzOi8vZ2FsbGVyeS5henVyZS5jb20vIiwKICAibWFuYWdlbWVudEVuZHBvaW50VXJsIjogImh0dHBzOi8vbWFuYWdlbWVudC5jb3JlLndpbmRvd3MubmV0LyIKfQo=


## Notes 
terraform init -backend-config="storage_account_name=prbterraformhomolog" -backend-config="container_name=tfstate" -backend-config="access_key=oE21bqjeY36xb8m2ZmNFmZYpg5RisJ18Cork8qaDgUg8oIzmEKVAM8vO78rmEhc5HLJ46PGsqkiRsHXdFrSlBw==" -backend-config="key=codelab.microsoft.tfstate"

az aks get-credentials --resource-group Prb_AKS --name k8s-pega

kubectl create clusterrolebinding kubernetes-dashboard --clusterrole=cluster-admin --serviceaccount=kube-system:kubernetes-dashboard

az aks browse --resource-group Prb_AKS --name k8s-pega


k8s-pega

SQL 
syssa
%dk)]hZ#3nk[!A&r


10.150.14.

azure_pega
10.150.14.96/27 
azure_redevirtual





applicationgatewayv2 -> 


## OK
https://learn.hashicorp.com/terraform/kubernetes/provision-aks-cluster
az ad sp create-for-rbac --skip-assignment --name PrbAKSPegaHomolog
Changing "PrbAKSPegaHomolog" to a valid URI of "http://PrbAKSPegaHomolog", which is the required format used for service principal names
{
  "appId": "0ba4a576-c62f-48f7-a68b-73c3328e598a",
  "displayName": "PrbAKSPegaHomolog",
  "name": "http://PrbAKSPegaHomolog",
  "password": "7076c698-737a-456b-a8c4-ac1598141e70",
  "tenant": "502fe815-28ec-4a53-95a9-13bc724e318b"
}



az aks get-credentials --resource-group Azure_AKS --name k8s-pega

kubectl create clusterrolebinding kubernetes-dashboard --clusterrole=cluster-admin --serviceaccount=kube-system:kubernetes-dashboard

az aks browse --resource-group Azure_AKS --name k8s-pega

# 
terraform plan -out out.plan 
terraform apply out.plan 


## Pega
https://community.pega.com/knowledgebase/articles/client-managed-cloud/cloud/client-managed-cloud
https://community.pega.com/knowledgebase/articles/client-managed-cloud-deployments-prior-pega-platform-82/client-managed-cloud-deployments-prior-pega-platform-82
https://community.pega.com/knowledgebase/articles/client-managed-cloud-deployments-prior-pega-platform-82/deploying-pega-platform-ms-azure
https://github.com/pegasystems/pega-helm-charts
https://github.com/pegasystems/pega-helm-charts/blob/master/docs/prepping-local-system-runbook-linux.md#downloading-a-pega-platform-installer-docker-image


https://github.com/pegasystems/pega-helm-charts/blob/master/docs/Deploying-Pega-on-AKS.md -> Usando


## Pega Login 
docker login pega-docker.downloads.pega.com
docker login -u reg-584689 -p AKCp5fTtyAcngkwCh1V1U537gcmKgfL1qJxEqfauQc4VejZJoGimn8jVP6L8G3ccbqHyahtuN pega-docker.downloads.pega.com


docker pull pega-docker.downloads.pega.com/platform/pega:8.4.0

cd /root/pega-helm-charts/charts/pega
helm dependency update
helm install . -n mypega --namespace pega --values ./values-minimal.yaml --generate-name
NAME: chart-1595425218
LAST DEPLOYED: Wed Jul 22 10:40:18 2020
NAMESPACE: pega
STATUS: deployed
REVISION: 1
TEST SUITE: None


## Streamsets 
/var/lib/sdc/runInfo  -> pipelines
madrugada para fazer a manutenção do disco -> a partir das 21:00


## Arquivos
https://prbterraformhomolog.blob.core.windows.net/scripts/GI_Atualizacao_V1.0_U15.zip
https://prbterraformhomolog.blob.core.windows.net/scripts/GI_Atualizacao_V1.0_U17.zip


## 
prbpega-sqldb-aks-hom01
sqlserver-prbpega-sqldb-aks-hom01.database.windows.net

servidor: sqlserver-prbpega-sqldb-aks-hom01
banco: prbpega-sqldb-aks-hom01
usuário: user_h_aks
senha: dk982IxL38r17p

jdbc:sqlserver://sqlserver-prbpega-sqldb-aks-hom01.database.windows.net:1433;databaseName=prbpega-sqldb-aks-hom01;selectMethod=cursor;sendStringParametersAsUnicode=false:

