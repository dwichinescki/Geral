## Connect to the cluster
```bash
az aks install-cli
```

## Get Credentials 
```bash
az aks get-credentials --resource-group pega-aks-01 --name pega-aks-01
Merged "pega-aks-01" as current context in C:\Users\douglasqs\.kube\config
```

## Remove Resource Group
```bash
az group delete --name homolog-aks
```

## Kubernetes Dashboard
Make sure the Azure k8s dashboard is disabled
```bash
az aks disable-addons -g pega-aks-01 -n pega-aks-01 -a kube-dashboard
```

- https://www.replex.io/blog/how-to-install-access-and-add-heapster-metrics-to-the-kubernetes-dashboard
- https://github.com/kubernetes/dashboard
- https://github.com/kubernetes/dashboard/blob/master/docs/user/access-control/creating-sample-user.md

Installing the Dash
```bash
kubectl delete -f https://raw.githubusercontent.com/kubernetes/dashboard/master/aio/deploy/recommended.yaml
kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/master/aio/deploy/recommended.yaml
kubectl delete -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.0.3/aio/deploy/recommended.yaml
kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.0.3/aio/deploy/recommended.yaml
```

Creating the user to access
```yaml
vim k8s-dash-adminuser.yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: admin-user
  namespace: kubernetes-dashboard
```

Creating the clusterrole
```yaml
vim k8s-dash-clusterrole.yml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: admin-user
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: cluster-admin
subjects:
- kind: ServiceAccount
  name: admin-user
  namespace: kubernetes-dashboard
```

Applying
```bash
kubectl.exe apply -f .\k8s-dash-adminuser.yml
kubectl.exe apply -f .\k8s-dash-clusterrole.yml
```

Getting the bearer Token PS
```bash
kubectl -n kubernetes-dashboard describe secret $(kubectl -n kubernetes-dashboard get secret | sls admin-user |
>> ForEach-Object { $_ -Split '\s+' } | Select -First 1)
Name:         admin-user-token-hjztf
Namespace:    kubernetes-dashboard
Labels:       <none>
Annotations:  kubernetes.io/service-account.name: admin-user
              kubernetes.io/service-account.uid: b781bbbd-d8b1-4f8a-8c54-5f26dc0acde6

Type:  kubernetes.io/service-account-token

Data
====
ca.crt:     1720 bytes
namespace:  20 bytes
token:      eyJhbGciOiJSUzI1NiIsImtpZCI6IiJ9.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlcm5ldGVzLWRhc2hib2FyZCIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJhZG1pbi11c2VyLXRva2VuLWhqenRmIiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQubmFtZSI6ImFkbWluLXVzZXIiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiJiNzgxYmJiZC1kOGIxLTRmOGEtOGM1NC01ZjI2ZGMwYWNkZTYiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6a3ViZXJuZXRlcy1kYXNoYm9hcmQ6YWRtaW4tdXNlciJ9.porWkZaSnBCPo11Th7KPZhO29aARc640TV80MCQkPmg0FXXFdffHBOiCAe5C3hGNTnWC7JWDZ4_OoMDBdGODTLtNMHO0kf7WXoudpM67kkiPJCymwY3ofsylriY7p2o9xc6BPeztTwIqdXnTvgZmn_aGD0jtUygYAekb9zkgWhcXVYfP-oicMVExspqMQZqj98Ef-R5e8OvfL8A0V3YiI-IuRHlILWAr904hGWU0ZIMNj7nxhMmHc5wiyJ2cW3qhKRkDG9HrYlzulBz6c92Ogf9i9DH_0aBmdkzvVflyMrV4OyW8BJgRoGmrsauHBHOQJn8JTepynr6BUMJpXb3UBM3weRDwmjIc--NlrzZUVO4_M3_zyEV5awkPkfvTBrWPZ964k-UTuyFq0qwQ_DHJ0n1YrnIm6DJ06tk90ItN1cFYM94wqRWH9aBRNlubKs8APF2W40TmMXWg9oj6lu1lBn2Yu1WGUOW1W8aGHU33kIUIcHh3A3uXCSgQjrRDGrZ9AFhaSulXZsug3JJRIXAAFoufqt0EB1ooVyvUnAWLVU9GKLUVDQ0vHR7wyDI5-6HsSYIAzonyx9KkdgarDl-a1HrWLwVcvl6LyffPscie6XbWd_HpIMeQS3A2mTIDas8lQ4zQxc9cWNgfiDl2e1ZTHuumXaAX-rNLDV_S5kPukoo
```

Getting the bearer token Bash
```bash
kubectl -n kubernetes-dashboard describe secret $(kubectl -n kubernetes-dashboard get secret | grep admin-user | awk '{print $1}')
```


Getting the secrets
```bash
kubectl get secrets -n kubernetes-dashboard | sls admin-user
admin-user-token-t9lgz             kubernetes.io/service-account-token   3      4m51s
```

Describing the secrets
```bash
kubectl describe secret admin-user-token-t9lgz -n kubernetes-dashboard
```

Exposing the dash
```
kubectl proxy
```

Accessing the Dashboard
- http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/#/login

## NS
kubectl.exe create namespace pega
namespace/pega created
kubectl.exe create namespace pegaaddons
namespace/pegaaddons created

cd C:\Users\douglasqs\Documents\git\pega-mssql\nginx\ssl
 kubectl.exe create secret tls hpbtechnetbr --cert hpbtechnetbr.crt --key hpbtechnetbr.key --namespace pega
secret/hpbtechnetbr create

## Updating Helm
helm repo update
Hang tight while we grab the latest from your chart repositories...
...Successfully got an update from the "pega" chart repository
...Successfully got an update from the "stable" chart repository
Update Complete. ⎈ Happy Helming!⎈

## Addons
helm install addons pega/addons --namespace pegaaddons --values addons-aks.yaml
NAME: addons
LAST DEPLOYED: Tue Aug 11 10:08:17 2020
NAMESPACE: pegaaddons
STATUS: deployed
REVISION: 1
TEST SUITE: None


## Pega Platform
helm install pega-aks pega/pega --namespace pega --values pega.yaml --set global.actions.execute=install-deploy
NAME: pega-aks
LAST DEPLOYED: Tue Aug 11 10:15:00 2020
NAMESPACE: pega
STATUS: deployed
REVISION: 1
TEST SUITE: None

## Pega without installation
helm install pega-aks pega/pega --namespace pega --values pega.yaml


helm fetch --untar pega/addons


helm install addons pega/addons --namespace pegaaddons --values .\addons-aks.yaml
Error: unable to build kubernetes objects from release manifest: unable to recognize "": no matches for kind "Deployment" in version "apps/v1beta2"

https://stackoverflow.com/questions/58481850/no-matches-for-kind-deployment-in-version-extensions-v1beta1

PS C:\Users\douglasqs\Documents\git\terraform-geral\azure-aks-pega-hom\src-yaml\pega> helm install addons pega/addons --namespace pegaaddons --values .\addons-aks.yaml
Error: unable to build kubernetes objects from release manifest: unable to recognize "": no matches for kind "Deployment" in version "apps/v1beta2"


PS C:\Users\douglasqs\Documents\git\terraform-geral\azure-aks-pega-hom\src-yaml\pega> helm install addons pega/addons --namespace pegaaddons --values .\addons-aks.yaml
Error: unable to build kubernetes objects from release manifest: unable to recognize "": no matches for kind "Deployment" in version "apps/v1beta2"

https://stackoverflow.com/questions/58481850/no-matches-for-kind-deployment-in-version-extensions-v1beta1
https://github.com/coreos/etcd-operator/issues/2126
https://github.com/helm/helm/issues/6926
https://github.com/kubernetes/kubernetes/issues/55894
https://github.com/helm/helm/issues/6969


choco install kubernetes-cli
choco install kubernetes-helm


helm install addons ./ --namespace pegaaddons --values ..\..\addons-aks.yaml
NAME: addons
LAST DEPLOYED: Mon Aug 10 17:34:20 2020
NAMESPACE: pegaaddons
STATUS: deployed
REVISION: 1
TEST SUITE: None


helm install mypega-aks-demo pega/pega --namespace pega --values pega.yaml --set global.actions.execute=install-deploy

helm install pega-aks pega/pega --namespace pega --values pega.yaml


url: "jdbc:sqlserver://prbsqlserverdev.database.windows.net:1433;databaseName=prbpega-sqldb-aks-hom01;selectMethod=cursor;sendStringParametersAsUnicode=false"
username: "user_h_aks@sqlserver-prbpega-sqldb-aks-hom01"
password: "dk982IxL38r17p"

CREATE LOGIN user_h_aks WITH PASSWORD = 'dk982IxL38r17p';
create user user_h_aks for login user_h_aks
EXEC sp_addrolemember 'db_owner','user_h_aks'

username: "user_h_aks@sqlserver-prbpega-sqldb-aks-hom01"

Creating the rules Schema
```sql
CREATE SCHEMA rules;
GO
```

Creating the data Schema
```sql
CREATE SCHEMA data;
GO
```

You can change manually as an alternative. Fetch the helm chart:

helm fetch --untar stable/metabase
Access the chart folder:

cd ./metabase
Change API version:

sed -i 's|extensions/v1beta1|apps/v1|g' ./templates/deployment.yaml
Add spec.selector.matchLabels:

spec:
[...]
selector:
    matchLabels:
    app: {{ template "metabase.name" . }}
[...]
Finally install your altered chart:

helm install ./ \
  -n metabase \
  --namespace metabase \
  --set ingress.enabled=true \
  --set ingress.hosts={metabase.$(minikube ip).nip.io}
Enjoy!

https://stackoverflow.com/questions/58481850/no-matches-for-kind-deployment-in-version-extensions-v1beta1


kubectl run -it --rm pega-alpine --image=alpine --namespace pega




- 942120 SQL Injection Attack: SQL Operator Detected
