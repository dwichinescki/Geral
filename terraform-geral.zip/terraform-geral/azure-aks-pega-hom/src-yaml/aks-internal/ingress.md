helm install nginx-ingress stable/nginx-ingress --namespace ingress-basic -f internal-ingress.yaml --set controller.replicaCount=2 --set controller.nodeSelector."beta\.kubernetes\.io/os"=linux --set defaultBackend.nodeSelector."beta\.kubernetes\.io/os"=linux
NAME: nginx-ingress
LAST DEPLOYED: Sun Aug  9 13:41:58 2020
NAMESPACE: ingress-basic
STATUS: deployed
REVISION: 1
TEST SUITE: None
NOTES:
The nginx-ingress controller has been installed.
It may take a few minutes for the LoadBalancer IP to be available.
You can watch the status by running 'kubectl --namespace ingress-basic get services -o wide -w nginx-ingress-controller'

An example Ingress that makes use of the controller:

  apiVersion: extensions/v1beta1
  kind: Ingress
  metadata:
    annotations:
      kubernetes.io/ingress.class: nginx
    name: example
    namespace: foo
  spec:
    rules:
      - host: www.example.com
        http:
          paths:
            - backend:
                serviceName: exampleService
                servicePort: 80
              path: /
    # This section is only required if TLS is to be enabled for the Ingress
    tls:
        - hosts:
            - www.example.com
          secretName: example-tls

If TLS is enabled for the Ingress, a Secret containing the certificate and key must also be provided:

  apiVersion: v1
  kind: Secret
  metadata:
    name: example-tls
    namespace: foo
  data:
    tls.crt: <base64 encoded cert>
    tls.key: <base64 encoded key>
  type: kubernetes.io/tls

eyJhbGciOiJSUzI1NiIsImtpZCI6IkVCNDEyekV3TVR2N0djRUVHcUhLNWRpVU5ZWUNRU1NPa0RCZVNwaUJjLUUifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJkZWZhdWx0Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZWNyZXQubmFtZSI6ImRhc2hib2FyZC1hZG1pbi1zYS10b2tlbi1rNHY5biIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50Lm5hbWUiOiJkYXNoYm9hcmQtYWRtaW4tc2EiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiI4NjJlYjllZC04YWViLTQzZjUtOGM0NC03MWQ4NTQ4NzM1OGIiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6ZGVmYXVsdDpkYXNoYm9hcmQtYWRtaW4tc2EifQ.R06YNPed6M3oohy8danmE8UUWQilLOSvWUx4smKKSROGs7A6UnRIoXApbSk3R4aDNtt-eamxw-V8p_mpL4_oZLucb2opN6-Y4de40wduDJ5aRqGPaFyKaBpCeUBR5Ik4zTVNc5naGjzOmumR5HNNC87T7J0DcRcSSmsJ-PvrmGuQoexjTLv4W2Hlj7ukZqzCb0gLbPywGOh_XUglsyVokW-yViI8DmNxUzUrFwiewss-27cXdthWxnE_UGr9habYpXoNJ8uUIVnw6qI8eQc3KW_nrfB5D0e6A-VTr6Jxtx0YswcoTD6c7iYk82GdMhTZW1-udBQp4SYfZBEjzAv2U0xWhVnUV4dr5a_NzsQjyoypSeAdzr-KZ8jrV50mI14vdWDgyIkETcZVd70ZsIXPLOHPPBMIFPO88y0Y4Ia097Lu_ue10AToen-pBwLd-lSAgmwyxdx-sC75Zw9zMj-58vrrI95Rj5-1yS06X0RQvv9ApNJGQrm7jlJ-3GcLU550-dLmvCsh92P3Y2ezQ_iWWZxdeYxmLn89fbnNIIVQUVVLwBpHf_221fbOXytEeT_0Xuwz2DrWRnhMQTLqmkRjJ9293SmP86tMtxY7j1xMDIWQ_7jo5O7BLtXTF5_H52EW5G2dLmbV09Ot4FtOF3xahw3WBl63TpS0-6qmbREsywQ


## Internal Ingress
https://docs.microsoft.com/en-us/azure/aks/ingress-internal-ip
https://docs.microsoft.com/en-us/azure/aks/ingress-basic#test-the-ingress-controller

https://docs.microsoft.com/en-us/azure/aks/configure-kubenet

## AKS
https://docs.microsoft.com/en-us/azure/aks/kubernetes-walkthrough
https://www.replex.io/blog/how-to-install-access-and-add-heapster-metrics-to-the-kubernetes-dashboard
https://github.com/kubernetes/dashboard
https://github.com/kubernetes/dashboard/blob/master/docs/user/access-control/creating-sample-user.md
https://kubernetes.io/docs/tasks/access-application-cluster/web-ui-dashboard/

https://www.terraform.io/docs/providers/azurerm/r/application_gateway.html

https://github.com/pegasystems/pega-helm-charts/blob/master/docs/Deploying-Pega-on-AKS.md