## API Keys

- [0] - Homolog
- [1] - Dev

 app_id = [
  "a9c8e986-c8b3-4e4f-956d-56f22a122812",
  "cda5c5bb-2b73-467b-a429-b460abeaf6cf",
]
authenticate_sdk_control_channel_api_key = [
  "ad56xhba2fve8gqj36ddbmvhjyis0rb2rd2sjkrh",
  "p8wzd88qnkbxg2a8n0jzdc7t7nfc6wet6wxtoflx",
]
full_permissions_api_key = [
  "j5bx72fqvdtrn27oobvfkzbzdwszdrtux4e5da3s",
  "xyk0zzo2pnob7tqzeol53phx6udy5pelxbolgpjm",
]
instrumentation_key = [
  "8b990fb9-1aac-4eb4-ad50-a01ca0d75852",
  "2393c55a-d0bd-4b6c-822f-71432faeb299",
]
read_telemetry_api_key = [
  "v5tq2sj4kje5v4cw8juz6x7gefopll132wnala0e",
  "xj8xck0gtljk1yno2tzpcrr5zjldl0vdxvecnu2k",
]
write_annotations_api_key = [
  "t41xffdf6fujslf3gg4w0i43kgllvljqhkabpyyu",
  "gq3fvn14to08buw083fqp1sbu748hdgh4im1c4bh",
]