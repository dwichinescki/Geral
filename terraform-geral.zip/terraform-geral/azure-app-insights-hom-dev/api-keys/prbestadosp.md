## API Keys

- [0] - Homolog
- [1] - Dev


app_id = [
  "416d0e9c-a442-4339-a227-8140c4e1a50b",
  "01bf5ac0-5b36-48f8-8b05-ad1491728143",
]
authenticate_sdk_control_channel_api_key = [
  "l0j8ewaz4nlpvvquwh16klnx46lss55itf687xpf",
  "swdwhpvgip7jvp8qhjlom4l0lac1q31kku4np4mx",
]
full_permissions_api_key = [
  "f5qq8014b0lhmu648rg4cguv2onropg8qo2ibb15",
  "fpig4n4dgjs8gndvpjg8je2rx8e4t4br07i5kdpx",
]
instrumentation_key = [
  "c6fb767b-d1ca-4a80-a272-1c828b205a52",
  "e2c4ae78-329c-46ab-bfa9-6815b60b9847",
]
read_telemetry_api_key = [
  "jmp755tjioba1iarnsp2kbmw7kr1hedskut0xx3r",
  "6zvqbf866t1yajw0mc8ti2e8rwxcebqbikzqvzyo",
]
write_annotations_api_key = [
  "t6ch3jcf3vdlnxpq0heo3t6l0x7jtlerna3r3f8h",
  "1tng7eeviiepl48wnfhn1b8otce5scabekd2hnvi",
]