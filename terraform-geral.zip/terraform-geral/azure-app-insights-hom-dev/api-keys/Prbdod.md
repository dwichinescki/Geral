## API Keys

- [0] - Homolog
- [1] - Dev

App ID
```
app_id = [
  "00cf2661-d414-4e66-91f3-90b4bd1f86e8",
  "b0b63a95-7ccf-4b7c-85dd-6f03824e6560",
]
```

Instrumentation Key
```
instrumentation_key = [
  "6b58dc1e-59cc-42ef-810f-710ad15d0b83",
  "23bfa773-945b-4cde-b2b3-931ed16c3749",
]
```

authenticate sdk Control Channel Api Key
```
authenticate_sdk_control_channel_api_key = [
  "561eqqf6czbjf20xmz6zqqnki5lbudtpe2xi61mv",
  "0p2742htvyl0extw3wfmnyygypon1fjn5ooi5jin",
]
```

Full Permission Api Key
```
full_permissions_api_key = [
  "8o2fpthob6sj42xj68amvpv4dvjyv7xji1xnmowk",
  "dwkc8b88mlfcgoqni7h4pagcqlr7h8znlx14yaqy",
]
```

Read Telemetry Api Key
```
read_telemetry_api_key = [
  "ov8ihksrvbp6mcgjzx3kxcrvdelg8gi7vld1p11x",
  "2xjnhtlmlufkj531cg5fndwrajp7ajcgx2ikdvk7",
]
```

Write Annotations Api Key
```
write_annotations_api_key = [
  "0wmfwbt7ishud68yvs055qvwyaiev2ppdqs8uoft",
  "2hn21idbvfoum6nclof42aotbs3hsrjasb477sza",
]
```