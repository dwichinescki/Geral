# Pega on AKS

## Execution
- Apply the terraform: azure-aks-pega
- Follow the next steps below

## Executing the terraform

Change the values in variables.tf and run the terraform plan
```bash
terraform plan
Refreshing Terraform state in-memory prior to plan...
The refreshed state will be used to calculate this plan, but will not be
persisted to local or remote state storage.

------------------------------------------------------------------------

An execution plan has been generated and is shown below.  
Resource actions are indicated with the following symbols:
  + create

Terraform will perform the following actions:       

  # azurerm_application_gateway.main will be created
  + resource "azurerm_application_gateway" "main" { 
      + enable_http2        = false
      + id                  = (known after apply)
      + location            = "brazilsouth"      
      + name                = "pega-aks-01"      
      + resource_group_name = "pega-aks-01"      
      + tags                = (known after apply)

      + autoscale_configuration {
          + max_capacity = 10
          + min_capacity = 2
        }
[...]
Plan: 12 to add, 0 to change, 0 to destroy.

------------------------------------------------------------------------

Note: You didn't specify an "-out" parameter to save this plan, so Terraform
can't guarantee that exactly these actions will be performed if
"terraform apply" is subsequently run.
```

Now if you are sure that everything is configure property just run the terraform apply
```bash
terraform apply -auto-approve
[...]
azurerm_application_gateway.main: Still creating... [4m41s elapsed]
azurerm_application_gateway.main: Still creating... [4m51s elapsed]
azurerm_application_gateway.main: Still creating... [5m1s elapsed]
azurerm_application_gateway.main: Still creating... [5m11s elapsed]
azurerm_application_gateway.main: Still creating... [5m21s elapsed]
azurerm_application_gateway.main: Still creating... [5m31s elapsed]
azurerm_application_gateway.main: Creation complete after 5m34s [id=/subscriptions/19d24e10-1ddf-4f7e-9615-abd8dc3b88d3/resourceGroups/pega-aks-01/providers/Microsoft.Network/applicationGateways/pega-aks-01]

Apply complete! Resources: 12 added, 0 changed, 0 destroyed.

Outputs:

dns_private_endpoint_private_fqdn_mssql = pega-aks-01-db.h.pbtech.net.br.
dns_private_endpoint_private_ip_mssql = 10.150.2.225
dns_public_ip_fqdn = pega-aks-01.h.pbtech.net.br.
mssql_database_names = [
  "pega-aks-01-db-dev",
  "pega-aks-01-db-hom",
]
mssql_db_server_name = pega-aks-01-db-server
mssql_db_syssa_connection = syssa@pega-aks-01-db-server
mssql_syssa_password = SOME_PASSWORD
mssql_syssa_user = syssa
public_ip_address = 191.234.218.244
```

You can double check the output variables with the follow command
```bash
terraform output
dns_private_endpoint_private_fqdn_mssql = pega-aks-01-db.h.pbtech.net.br.
dns_private_endpoint_private_ip_mssql = 10.150.2.225
dns_public_ip_fqdn = pega-aks-01.h.pbtech.net.br.
mssql_database_names = [
  "pega-aks-01-db-dev",
  "pega-aks-01-db-hom",
]
mssql_db_server_name = pega-aks-01-db-server
mssql_db_syssa_connection = syssa@pega-aks-01-db-server
mssql_syssa_password = SOME_PASSWORD
mssql_syssa_user = syssa
public_ip_address = 191.234.218.244
```

## Create a User for Development

Create a new User select pega-aks-01-db-dev on the panel
```SQL
-- acessar o banco de dados que eu preciso de acesso on the panel
CREATE USER user_aks_01_dev WITH password = 'PASSWORD'
ALTER ROLE db_datareader ADD MEMBER user_aks_01_dev
ALTER ROLE db_datawriter ADD MEMBER user_aks_01_dev
ALTER ROLE db_ddladmin ADD MEMBER user_aks_01_dev
```

Connect always with user@db_server
```
USER: user_aks_01_dev@pega-aks-01-db-server
PASS: PASSWORD
DB_SERVER: pega-aks-01-db.h.pbtech.net.br
DB: pega-aks-01-db-dev
```

## Create a User for Homolog

Create a new User select pega-aks-01-db-hom on the panel
```SQL
-- acessar o banco de dados que eu preciso de acesso on the panel
CREATE USER user_aks_01_hom WITH password = 'PASSWORD'
ALTER ROLE db_datareader ADD MEMBER user_aks_01_hom
ALTER ROLE db_datawriter ADD MEMBER user_aks_01_hom
ALTER ROLE db_ddladmin ADD MEMBER user_aks_01_hom
```

Connect always with user@db_server
```
USER: user_aks_01_hom@pega-aks-01-db-server
PASS: PASSWORD
DB_SERVER: pega-aks-01-db.h.pbtech.net.br
DB: pega-aks-01-db-hom
```


## Get Credentials 
```bash
az aks get-credentials --resource-group pega-aks-01 --name pega-aks-01
Merged "pega-aks-01" as current context in C:\Users\douglasqs\.kube\config
```

Listing the contexts
```bash
kubectl config get-contexts
CURRENT   NAME          CLUSTER       AUTHINFO                              NAMESPACE
*         pega-aks-01   pega-aks-01   clusterUser_pega-aks-01_pega-aks-01
```

Changing the context
```bash
kubectl config use-context pega-aks-01
```

## Kubernetes Dashboard
Make sure the Azure k8s dashboard is disabled
```bash
az aks disable-addons -g pega-aks-01 -n pega-aks-01 -a kube-dashboard
```

Installing the Dash, the remove may output some errors if the dashboard is not installed
```bash
kubectl delete -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.0.3/aio/deploy/recommended.yaml
kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.0.3/aio/deploy/recommended.yaml
```

Creating the user to access the dashboard
```bash
kubectl.exe apply -f .\dashboard\k8s-dash-adminuser.yml
serviceaccount/admin-user created
```

Creating the clusterrole
```bash
kubectl.exe apply -f .\dashboard\k8s-dash-clusterrole.yml
clusterrolebinding.rbac.authorization.k8s.io/admin-user created
```

Getting the bearer Token PS
```bash
kubectl -n kubernetes-dashboard describe secret $(kubectl -n kubernetes-dashboard get secret | sls admin-user | ForEach-Object { $_-Split '\s+' } | Select -First 1)
Name:         admin-user-token-klx82
Namespace:    kubernetes-dashboard
Labels:       <none>
Annotations:  kubernetes.io/service-account.name: admin-user
              kubernetes.io/service-account.uid: e07f4847-3fc0-4c6e-a6b3-697d4d4dc320

Type:  kubernetes.io/service-account-token

Data
====
ca.crt:     1720 bytes
namespace:  20 bytes
token:      TOKEN
```

Getting the bearer token Bash
```bash
kubectl -n kubernetes-dashboard describe secret $(kubectl -n kubernetes-dashboard get secret | grep admin-user | awk '{print $1}')
```

Getting the secrets
```bash
kubectl get secrets -n kubernetes-dashboard | sls admin-user
admin-user-token-klx82             kubernetes.io/service-account-token   3      2m3s
```

Describing the secrets
```bash
kubectl describe secret admin-user-token-klx82 -n kubernetes-dashboard
Name:         admin-user-token-klx82
Namespace:    kubernetes-dashboard
Labels:       <none>
Annotations:  kubernetes.io/service-account.name: admin-user
              kubernetes.io/service-account.uid: e07f4847-3fc0-4c6e-a6b3-697d4d4dc320

Type:  kubernetes.io/service-account-token

Data
====
ca.crt:     1720 bytes
namespace:  20 bytes
token:      TOKEN
```

65200-65535

Exposing the dash
```
kubectl proxy
```

Accessing the Dashboard
- http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/#/login

## Chrome Isseus

If you have some issues to access the Kubernetes dashboard 

In Chrome type: chrome://flags/
Search for samesite:
  - Disable: SameSite by default cookies
  - Disable: Enable removing SameSite=None cookies
  - Disable: Cookies without SameSite must be secure

## Importing the Database

Connect always with user_aks_01_dev@pega-aks-01-db-server
```
USER: user_aks_01_dev@pega-aks-01-db-server
PASS: PASSWORD
DB_SERVER: pega-aks-01-db.h.pbtech.net.br
DB: pega-aks-01-db-dev
```

Connect always with user_aks_01_hom@pega-aks-01-db-server
```
USER: user_aks_01_hom@pega-aks-01-db-server
PASS: PASSWORD
DB_SERVER: pega-aks-01-db.h.pbtech.net.br
DB: pega-aks-01-db-hom
```

Creating rules and data Schema
```sql
CREATE SCHEMA rules;
GO

CREATE SCHEMA data;
GO
```

Creating the directory to store the files
```bash
mkdir -p /var/lib/docker/data/Sources && cd /var/lib/docker/data/Sources
```

Download the Pega and the Hotfix
```bash
wget -c https://prbterraformhomolog.blob.core.windows.net/scripts/116826_Pega8.42.zip
wget -c https://prbterraformhomolog.blob.core.windows.net/scripts/DL-118186_INC-140029.zip
wget -c https://prbterraformhomolog.blob.core.windows.net/scripts/mssql-jdbc-8.2.2.jre11.jar
```


Now we need to extract the file to import the database
```bash
unzip 116826_Pega8.42.zip
```

Now access the scripts directory
```bash
cd scripts/
```

Now configure the setupDatabase.properties file with the Database information.
```bash
vim setupDatabase.properties
[...]
# CONNECTION INFORMATION
pega.jdbc.driver.jar=/app/mssql-jdbc-8.2.2.jre11.jar
pega.jdbc.driver.class=com.microsoft.sqlserver.jdbc.SQLServerDriver
pega.database.type=mssql
pega.jdbc.url=jdbc:sqlserver://pega-aks-01-db.h.pbtech.net.br;databaseName=pega-aks-01-db-dev;selectMethod=cursor;sendStringParametersAsUnicode=false
pega.jdbc.username=user_aks_01_dev@pega-aks-01-db-server
pega.jdbc.password=PASSWORD

# TEMPORARY ADMIN PASSWORD - New installs only
# Set the temporary password for administrator@pega.com that is used to install Pega Platform.
# You must set a password before installing Pega Platform or the installation will fail.
# The password must be between 5 and 64 characters. You will be required to change this password on first login.
pega.admin.password=PEGA_ADMIN_PASSWORD

# CUSTOM CONNECTION PROPERTIES
# Uncomment this property and add a list of ; delimited connections properties
# The list must end with ;
# For example: jdbc.custom.connection.properties=user=usr;password=pwd;
#jdbc.custom.connection.properties=

# RULES SCHEMA NAME
# The default is the value specified for the user name
rules.schema.name=rules

# DATA SCHEMA NAME
# The default is the value specified for the rules schema name
data.schema.name=data

[...]
```

Now configure the prpcUtils.properties file with the Database information.
Configuring the hotfix
```bash
vim utils/prpcUtils.properties
[...]
pega.jdbc.driver.jar=/app/mssql-jdbc-8.2.2.jre11.jar
pega.jdbc.driver.class=com.microsoft.sqlserver.jdbc.SQLServerDriver
pega.database.type=mssql
pega.jdbc.url=jdbc:sqlserver://pega-aks-01-db.h.pbtech.net.br;databaseName=pega-aks-01-db-dev;selectMethod=cursor;sendStringParametersAsUnicode=false
pega.jdbc.username=user_aks_01_dev@pega-aks-01-db-server
pega.jdbc.password=PASSWORD
[...]
# RULES SCHEMA NAME
# The default is the value specified for the user name
rules.schema.name=rules

# DATA SCHEMA NAME
# The default is the value specified for the rules schema name
data.schema.name=data
[...]
# HOTFIX OPERATION
# Valid values are commit, rollback, generateDDL, install, and scan.
hotfix.operation=install

# PATH TO DDL FILE
# If generateDDL or install is chosen, provide a path to a DL file.
hotfix.DLFilePath=/app/DL-118186_INC-140029.zip
```

Now start the screen, because the process can take a while
```bash
screen -S load_database
```

Access the root directory
```bash
cd /var/lib/docker/data/Sources
```

Using the Docker openjdk image
```bash
docker run --rm -it -v "$PWD":/app -w /app openjdk:11 bash
```

Acessing the directory with the scripts
```bash
cd /app/scripts
```

Now run the installer
```bash
./install.sh | tee -a /app/pega-$(date +%F-as-%H-%M-%S).log
```

Now access the scripts directory
```bash
cd /app/scripts/utils/
```

Appling the hotfix
```bash
./prpcUtils.sh manageHotfixes --hotfix.operation install | tee -a /app/hotfix-$(date +%F-as-%H-%M-%S).log
```

Exit from the container.
```bash
exit
```

Get the credentials to connect into kubernetes

Creating the namespace for pega dev, make sure that you have the credentials
```bash
kubectl.exe create namespace pega-dev
namespace/pega created
```

Creating the namespace for pega hom, make sure that you have the credentials
```bash
kubectl.exe create namespace pega-hom
namespace/pega created
```

Creating the namespace for pegaaddons
```bash
kubectl.exe create namespace pegaaddons
namespace/pegaaddons created
```

Configuring the SSL for pega dev
```bash
cd ssl
kubectl.exe create secret tls hpbtechnetbr --cert hpbtechnetbr.crt --key hpbtechnetbr.key --namespace pega-dev
secret/hpbtechnetbr create
```

Configuring the SSL for pega hom
```bash
kubectl.exe create secret tls hpbtechnetbr --cert hpbtechnetbr.crt --key hpbtechnetbr.key --namespace pega-hom
secret/hpbtechnetbr create
```

Back one directory
```bash
cd ..
```

Adding the helm charts repo
```bash
helm repo add pega https://dl.bintray.com/pegasystems/pega-helm-charts
```

Checking the version of the charts
```bash
helm search repo pega
NAME            CHART VERSION   APP VERSION     DESCRIPTION
pega/pega       1.2.10                          Pega installation on kubernetes
pega/addons     1.2.10          1.0             A Helm chart for Kubernetes
```

Updating the helm chart repo
```bash
helm repo update
Hang tight while we grab the latest from your chart repositories...
...Successfully got an update from the "pega" chart repository
...Successfully got an update from the "stable" chart repository
Update Complete. ⎈ Happy Helming!⎈
```

Installing the addons, on the root of the azure-aks-pega-03-hom, make sure that the configuration is working. If you are using kubernetes bellow 1.16 the warning will not appear
```bash
helm install addons pega/addons --namespace pegaaddons --values .\pega\addons-aks.yaml
Error: unable to build kubernetes objects from release manifest: unable to recognize "": no matches for kind "Deployment" in version "apps/v1beta2"
```

Now we need to download the chart and update the deployment
```bash
helm fetch --untar pega/addons
```

Now we need to update the deployment
```bash
vim .\addons\charts\ingress-azure\templates\deployment.yaml
apiVersion: apps/v1
[...]
```

Now we can deploy the chart again
```bash
helm install addons .\addons\ --namespace pegaaddons --values .\pega\addons-aks.yaml
NAME: addons
LAST DEPLOYED: Fri Aug 14 12:01:13 2020
NAMESPACE: pegaaddons
STATUS: deployed
REVISION: 1
TEST SUITE: None
```

After deploy the addons take a look at the kubernetes dashboard and make sure that everything is working.
```bash
kubectl get all -n pegaaddons
NAME                                        READY   STATUS    RESTARTS   AGE
pod/addons-ingress-azure-79966c696c-8dv2c   1/1     Running   0          110s

NAME                                   READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/addons-ingress-azure   1/1     1            1           110s

NAME                                              DESIRED   CURRENT   READY   AGE
replicaset.apps/addons-ingress-azure-79966c696c   1         1         1       110s
```

Take a look at the logs
```bash
kubectl logs -f addons-ingress-azure-79966c696c-8dv2c -n pegaaddons
ERROR: logging before flag.Parse: I0817 20:46:20.965154       1 main.go:302] Using verbosity level 3 from environment variable APPGW_VERBOSITY_LEVEL
I0817 20:46:21.032734       1 environment.go:168] KUBERNETES_WATCHNAMESPACE is not set. Watching all available namespaces.
I0817 20:46:21.032756       1 main.go:132] App Gateway Details: Subscription: 19d24e10-1ddf-4f7e-9615-abd8dc3b88d3, Resource Group: homolog-aks-03, Name: homolog-aks-03
I0817 20:46:21.032763       1 auth.go:81] Creating authorizer from file referenced by environment variable: /etc/Azure/Networking-AppGW/auth/armAuth.json
I0817 20:46:21.894174       1 main.go:179] Ingress Controller will observe all namespaces.
I0817 20:46:21.933567       1 context.go:129] k8s context run started
I0817 20:46:21.933606       1 context.go:168] Waiting for initial cache sync
I0817 20:46:22.033879       1 context.go:176] Initial cache sync done
I0817 20:46:22.033905       1 context.go:177] k8s context run finished
I0817 20:46:22.033973       1 worker.go:35] Worker started
I0817 20:46:22.034031       1 httpserver.go:57] Starting API Server on :8123
I0817 20:46:22.183646       1 mutate_app_gateway.go:154] BEGIN AppGateway deployment
I0817 20:46:52.820177       1 mutate_app_gateway.go:182] Applied App Gateway config in 30.636497075s
I0817 20:46:52.820207       1 mutate_app_gateway.go:198] cache: Updated with latest applied config.
I0817 20:46:52.821213       1 mutate_app_gateway.go:203] END AppGateway deployment
```

## Deploying Dev

Now change the configuration in the pega-dev.yaml before apply.

Applying the pega charts
```bash
helm install pega-dev pega/pega --namespace pega-dev --values .\pega\pega-dev.yaml
NAME: pega-dev
LAST DEPLOYED: Tue Aug 18 20:13:26 2020
NAMESPACE: pega-dev
STATUS: deployed
REVISION: 1
TEST SUITE: None
```

Now let's check the resources
```bash
kubectl get all -n pega-dev
NAME                              READY   STATUS     RESTARTS   AGE
pod/pega-batch-79c65c69d9-vjzhk   0/1     Init:0/1   0          31s
pod/pega-search-0                 0/1     Init:0/1   0          31s
pod/pega-stream-0                 0/1     Init:0/1   0          31s
pod/pega-web-7694cdfbfc-dnxph     0/1     Init:0/1   0          31s

NAME                            TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)          AGE
service/pega-search             ClusterIP   10.129.253.179   <none>        80/TCP           31s
service/pega-search-transport   ClusterIP   None             <none>        80/TCP           31s
service/pega-web                NodePort    10.129.93.39     <none>        8080:30975/TCP   31s

NAME                         READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/pega-batch   0/1     1            0           31s
deployment.apps/pega-web     0/1     1            0           31s

NAME                                    DESIRED   CURRENT   READY   AGE
replicaset.apps/pega-batch-79c65c69d9   1         1         0       32s
replicaset.apps/pega-web-7694cdfbfc     1         1         0       32s

NAME                           READY   AGE
statefulset.apps/pega-search   0/1     32s
statefulset.apps/pega-stream   0/1     32s
```

Double check the pega-web logs
```bash
kubectl logs -f pega-web-7694cdfbfc-dnxph -n pega-dev
```

After all the pods become available we shall have something like
```bash
kubectl get all -n pega-dev
NAME                             READY   STATUS    RESTARTS   AGE
pod/pega-batch-b4bf456cd-z8p7h   1/1     Running   0          18h
pod/pega-search-0                1/1     Running   0          18h
pod/pega-stream-0                1/1     Running   0          18h
pod/pega-stream-1                1/1     Running   0          18h
pod/pega-web-c78f77566-86vp2     1/1     Running   0          18h

NAME                            TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)        AGE
service/pega-search             ClusterIP   10.129.160.163   <none>        80/TCP         18h
service/pega-search-transport   ClusterIP   None             <none>        80/TCP         18h
service/pega-web                NodePort    10.129.204.30    <none>        80:31808/TCP   18h

NAME                         READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/pega-batch   1/1     1            1           18h
deployment.apps/pega-web     1/1     1            1           18h

NAME                                   DESIRED   CURRENT   READY   AGE
replicaset.apps/pega-batch-b4bf456cd   1         1         1       18h
replicaset.apps/pega-web-c78f77566     1         1         1       18h

NAME                           READY   AGE
statefulset.apps/pega-search   1/1     18h
statefulset.apps/pega-stream   2/2     18h

NAME                                                 REFERENCE               TARGETS            MINPODS   MAXPODS   REPLICAS   AGE
horizontalpodautoscaler.autoscaling/pega-batch-hpa   Deployment/pega-batch   88%/85%, 4%/700%   1         5         1          18h
horizontalpodautoscaler.autoscaling/pega-web-hpa     Deployment/pega-web     89%/85%, 0%/700%   1         5         1          18h
```

## Deploying Homolog

Now change the configuration in the pega-hom.yaml before apply.

Applying the pega charts
```bash
helm install pega-hom pega/pega --namespace pega-hom --values .\pega\pega-hom.yaml
NAME: pega-hom
LAST DEPLOYED: Tue Aug 18 20:26:09 2020
NAMESPACE: pega-hom
STATUS: deployed
REVISION: 1
TEST SUITE: None
```

Now let's check the resources
```bash
kubectl get all -n pega-hom
NAME                              READY   STATUS     RESTARTS   AGE
pod/pega-batch-5f578dd4cc-jdrqn   0/1     Init:0/1   0          30s
pod/pega-search-0                 0/1     Init:0/1   0          30s
pod/pega-stream-0                 0/1     Init:0/1   0          30s
pod/pega-web-657c976b45-n4q9x     0/1     Init:0/1   0          30s

NAME                            TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)          AGE
service/pega-search             ClusterIP   10.129.71.239    <none>        80/TCP           30s
service/pega-search-transport   ClusterIP   None             <none>        80/TCP           30s
service/pega-web                NodePort    10.129.121.175   <none>        8081:31341/TCP   30s

NAME                         READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/pega-batch   0/1     1            0           30s
deployment.apps/pega-web     0/1     1            0           30s

NAME                                    DESIRED   CURRENT   READY   AGE
replicaset.apps/pega-batch-5f578dd4cc   1         1         0       30s
replicaset.apps/pega-web-657c976b45     1         1         0       30s

NAME                           READY   AGE
statefulset.apps/pega-search   0/1     30s
statefulset.apps/pega-stream   0/1     30s
```

Double check the pega-web logs
```bash
kubectl logs -f pega-web-7694cdfbfc-dnxph -n pega-dev
```

After all the pods become available we shall have something like
```bash
kubectl get all -n pega-dev
NAME                             READY   STATUS    RESTARTS   AGE
pod/pega-batch-b4bf456cd-z8p7h   1/1     Running   0          18h
pod/pega-search-0                1/1     Running   0          18h
pod/pega-stream-0                1/1     Running   0          18h
pod/pega-stream-1                1/1     Running   0          18h
pod/pega-web-c78f77566-86vp2     1/1     Running   0          18h

NAME                            TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)        AGE
service/pega-search             ClusterIP   10.129.160.163   <none>        80/TCP         18h
service/pega-search-transport   ClusterIP   None             <none>        80/TCP         18h
service/pega-web                NodePort    10.129.204.30    <none>        80:31808/TCP   18h

NAME                         READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/pega-batch   1/1     1            1           18h
deployment.apps/pega-web     1/1     1            1           18h

NAME                                   DESIRED   CURRENT   READY   AGE
replicaset.apps/pega-batch-b4bf456cd   1         1         1       18h
replicaset.apps/pega-web-c78f77566     1         1         1       18h

NAME                           READY   AGE
statefulset.apps/pega-search   1/1     18h
statefulset.apps/pega-stream   2/2     18h

NAME                                                 REFERENCE               TARGETS            MINPODS   MAXPODS   REPLICAS   AGE
horizontalpodautoscaler.autoscaling/pega-batch-hpa   Deployment/pega-batch   88%/85%, 4%/700%   1         5         1          18h
horizontalpodautoscaler.autoscaling/pega-web-hpa     Deployment/pega-web     89%/85%, 0%/700%   1         5         1          18h
```


Deleting the namespace and all the resources
```bash
kubectl delete namespace pega-dev
kubectl delete namespace pega-hom
```

## References
- https://github.com/pegasystems/pega-helm-charts/blob/master/charts/pega/README.md#liveness-and-readiness-probes
- https://kubernetes.io/docs/reference/kubectl/cheatsheet/
- https://docs.microsoft.com/en-us/azure/aks/kubernetes-walkthrough
- https://www.replex.io/blog/how-to-install-access-and-add-heapster-metrics-to-the-kubernetes-dashboard
- https://github.com/kubernetes/dashboard
- https://github.com/kubernetes/dashboard/blob/master/docs/user/access-control/creating-sample-user.md
- https://github.com/pegasystems/pega-helm-charts/blob/master/docs/Deploying-Pega-on-AKS.md
- https://community.pega.com/knowledgebase/articles/client-managed-cloud/cloud/meeting-requirements-and-prerequisites
- https://docs.microsoft.com/en-us/azure/aks/kubernetes-walkthrough-portal
- https://docs.microsoft.com/en-us/azure/container-registry/container-registry-helm-repos
- https://docs.microsoft.com/en-us/azure/aks/quickstart-helm
- https://istio.io/latest/docs/setup/getting-started/
- https://docs.microsoft.com/en-us/azure/aks/servicemesh-istio-install?pivots=client-operating-system-linux
- https://github.com/pegasystems/pega-helm-charts/blob/master/charts/pega/README.md#service
- https://github.com/pegasystems/pega-helm-charts/blob/master/charts/pega/README.md#ingress
- https://github.com/pegasystems/pega-helm-charts/blob/master/docs/Deploying-Pega-on-AKS.md
- https://kubernetes.io/docs/reference/kubectl/cheatsheet/
- https://kubernetes.io/docs/reference/kubectl/overview/#output-options