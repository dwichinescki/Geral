# import terraform
$cluster_name = "prod-sf03"
$subscription = "/subscriptions/cc49fda0-bf9d-4180-a778-1b69960dfe68"
$lb = "$subscription/resourceGroups/$cluster_name/providers/Microsoft.Network/loadBalancers/$($cluster_name)-lb"
$probe = "$lb/probes"
$rule = "$lb/loadBalancingRules"
$lb_back_addr_pool = "$lb/backendAddressPools/$($cluster_name)-pool"
$lb_nat_pool = "$lb/inboundNatPools/$($cluster_name)-nat-pool"
$apps = Get-Content -Path .\apps

## Clean the files
Remove-Item .\terraform.tfstate* -Force

# Importing the LoadBalancer
Write-Host "[+] Import the LB"
terraform import azurerm_lb.production_lb $lb

# Import the LB Backend Address Pool
Write-Host "[+] Import LB Backend Address Pool"
terraform import azurerm_lb_backend_address_pool.production_lb_backend_address_pool $lb_back_addr_pool

# Import the LB Nat Pool
Write-Host "[+] Import LB Nat Pool"
terraform import azurerm_lb_nat_pool.production_lb_nat_pool $lb_nat_pool

## Importing Probes
$index = 0
foreach($line in $apps) {
  $probe_app = "App_$($line)"
  Write-Host "[+] Importing Probes for App [$probe_app] Index [$index]"
  terraform import azurerm_lb_probe.production_lb_probe[$index] $probe/$probe_app
  $index += 1
}

## Importing Rules
$index = 0
foreach($line in $apps) {
  $rule_app = "App_$($line)"
  Write-Host "[+] Importing Rules for App [$rule_app] Index [$index]"
  terraform import azurerm_lb_rule.production_lb_rules[$index] $rule/$rule_app
  $index += 1
}

# Operator hub
# istio