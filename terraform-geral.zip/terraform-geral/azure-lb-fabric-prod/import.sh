#!/bin/bash

CLUSTER_NAME="homolog-sf02"
SUBSCRIPTION="/subscriptions/19d24e10-1ddf-4f7e-9615-abd8dc3b88d3"
LB="${SUBSCRIPTION}/resourceGroups/${CLUSTER_NAME}/providers/Microsoft.Network/loadBalancers/${CLUSTER_NAME}-lb"
PROBE="${LB}/probes"
RULE="${LB}/loadBalancingRules"
LB_BACK_ADDR_POOL="${LB}/backendAddressPools/${CLUSTER_NAME}-pool"
LB_NAT_POOL="${LB}/inboundNatPools/${CLUSTER_NAME}-nat-pool"
APP="apps"

echo "[+] Importing the LB"
terraform import azurerm_lb.production_lb ${LB}

echo "[+] Import LB Backend Address Pool"
terraform import azurerm_lb_backend_address_pool.production_lb_backend_address_pool ${LB_BACK_ADDR_POOL}

echo "[+] Import LB Nat Pool"
terraform import azurerm_lb_nat_pool.production_lb_nat_pool ${LB_NAT_POOL}

## Importing the Probes
INDEX=0
for end in $(cat $APP); do
  PROBE_APP="App_$end"
  echo "[+] Importing Probes for App ${PROBE_APP} Index [${INDEX}]"
  terraform import azurerm_lb_probe.production_lb_probe[${INDEX}] ${PROBE}/${PROBE_APP}
  INDEX=$((INDEX +1))
done

## Importing the Rules
INDEX=0
for end in $(cat $APP); do
  RULE_APP="App_$end"
  echo "[+] Importing Rules for App ${RULE_APP} Index [${INDEX}]"
  terraform import azurerm_lb_rule.production_lb_rules[${INDEX}] ${RULE}/${RULE_APP}
  INDEX=$((INDEX +1))
done
