# AKS 

- https://docs.microsoft.com/en-us/azure/aks/kubernetes-walkthrough

## Get Credentials 
```bash
az aks get-credentials --resource-group pega-aks-01 --name pega-aks-01
Merged "pega-aks-01" as current context in C:\Users\douglasqs\.kube\config
```

Listing the contexts
```bash
kubectl config get-contexts
CURRENT   NAME          CLUSTER       AUTHINFO                              NAMESPACE
*         pega-aks-01   pega-aks-01   clusterUser_pega-aks-01_pega-aks-01
```

Changing the context
```bash
kubectl config use-context pega-aks-01
```

## Kubernetes Dashboard
Make sure the Azure k8s dashboard is disabled
```bash
az aks disable-addons -g pega-aks-01 -n pega-aks-01 -a kube-dashboard
```

Installing the Dash, the remove may output some errors if the dashboard is not installed
```bash
kubectl delete -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.0.3/aio/deploy/recommended.yaml
kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.0.3/aio/deploy/recommended.yaml
```

Creating the user to access the dashboard
```bash
kubectl.exe apply -f .\dashboard\k8s-dash-adminuser.yml
serviceaccount/admin-user created
```

Creating the clusterrole
```bash
kubectl.exe apply -f .\dashboard\k8s-dash-clusterrole.yml
clusterrolebinding.rbac.authorization.k8s.io/admin-user created
```

Getting the bearer Token PS
```bash
kubectl -n kubernetes-dashboard describe secret $(kubectl -n kubernetes-dashboard get secret | sls admin-user | ForEach-Object { $_-Split '\s+' } | Select -First 1)
Name:         admin-user-token-klx82
Namespace:    kubernetes-dashboard
Labels:       <none>
Annotations:  kubernetes.io/service-account.name: admin-user
              kubernetes.io/service-account.uid: e07f4847-3fc0-4c6e-a6b3-697d4d4dc320

Type:  kubernetes.io/service-account-token

Data
====
ca.crt:     1720 bytes
namespace:  20 bytes
token:      TOKEN
```

Getting the bearer token Bash
```bash
kubectl -n kubernetes-dashboard describe secret $(kubectl -n kubernetes-dashboard get secret | grep admin-user | awk '{print $1}')
```

Getting the secrets
```bash
kubectl get secrets -n kubernetes-dashboard | sls admin-user
admin-user-token-klx82             kubernetes.io/service-account-token   3      2m3s
```

Describing the secrets
```bash
kubectl describe secret admin-user-token-klx82 -n kubernetes-dashboard
Name:         admin-user-token-klx82
Namespace:    kubernetes-dashboard
Labels:       <none>
Annotations:  kubernetes.io/service-account.name: admin-user
              kubernetes.io/service-account.uid: e07f4847-3fc0-4c6e-a6b3-697d4d4dc320

Type:  kubernetes.io/service-account-token

Data
====
ca.crt:     1720 bytes
namespace:  20 bytes
token:      TOKEN
```

65200-65535

Exposing the dash
```
kubectl proxy
```

Accessing the Dashboard
- http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/#/login

## Chrome Isseus

If you have some issues to access the Kubernetes dashboard 

In Chrome type: chrome://flags/
Search for samesite:
  - Disable: SameSite by default cookies
  - Disable: Enable removing SameSite=None cookies
  - Disable: Cookies without SameSite must be secure