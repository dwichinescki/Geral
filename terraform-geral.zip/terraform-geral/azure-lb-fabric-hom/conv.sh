#!/bin/bash

APP="apps"

for end in $(cat ${APP}); do
  echo -n "\"$end\","
done
