## Azure MSSQL - Homolog/Development

Edit the variables.tf and change values to hold the information about your project.