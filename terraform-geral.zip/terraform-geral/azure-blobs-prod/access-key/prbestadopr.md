```javascript
primary_access_key = [
  "2Y1y5nSSockhYTx/MyL3wCjeoKYyy9PKP640LJeNMpbBt87u31IHoxSe8DSd4/7k/s6Zj06aDwPutecCojE7Cg==",
]
primary_blob_connection_string = [
  "DefaultEndpointsProtocol=https;BlobEndpoint=https://prbestadoprprod.blob.core.windows.net/;AccountName=prbestadoprprod;AccountKey=2Y1y5nSSockhYTx/MyL3wCjeoKYyy9PKP640LJeNMpbBt87u31IHoxSe
8DSd4/7k/s6Zj06aDwPutecCojE7Cg==",
]
primary_blob_endpoint = [
  "https://prbestadoprprod.blob.core.windows.net/",
]
primary_connection_string = [
  "DefaultEndpointsProtocol=https;AccountName=prbestadoprprod;AccountKey=2Y1y5nSSockhYTx/MyL3wCjeoKYyy9PKP640LJeNMpbBt87u31IHoxSe8DSd4/7k/s6Zj06aDwPutecCojE7Cg==;EndpointSuffix=core.windows
.net",
]
secondary_access_key = [
  "cG6pwOVwp/N+vJ04K8/6uIT2nrJ8WS4rUQ2UbSB5t9MrWCJNJOKO7oQjd6meiPEMtVt0zmYflXewGUY/1MkzLg==",
]
secondary_blob_connection_string = [
  "",
]
secondary_connection_string = [
  "DefaultEndpointsProtocol=https;AccountName=prbestadoprprod;AccountKey=cG6pwOVwp/N+vJ04K8/6uIT2nrJ8WS4rUQ2UbSB5t9MrWCJNJOKO7oQjd6meiPEMtVt0zmYflXewGUY/1MkzLg==;EndpointSuffix=core.windows
.net",
]
```