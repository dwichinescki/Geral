## API Keys

- [0] - WebApi
- [1] - NextJS

app_id = [
  "182dfb8a-d649-43d5-b3fb-c012bc985b4b",
  "bf1150a0-3609-4e50-9a4e-e1ede1453133",
]
authenticate_sdk_control_channel_api_key = [
  "yrcherdbw0davtgzvptgfoojy7h6lumowibqdcfg",
  "v58ypg2zn6gsmhv1s8hld3p3apgd0txbm0pjja6q",
]
full_permissions_api_key = [
  "y77yv5mzqtux1xwdgexwphp7065jh8be3lfi6jmm",
  "ngr0caazrtynthgn1g8ox8e5rfxdvuftr57jlmkj",
]
instrumentation_key = [
  "e4b1b953-243b-4f7e-af06-3d50497e0806",
  "623f81f5-6ebc-4cb7-830e-1913f339fc43",
]
read_telemetry_api_key = [
  "jii7f7enhnqqs3bd6ki7njgtu23nnguyeywlxjj6",
  "hrjqpgwtjuh842ahpvphaao5mwz7wc5keyceloln",
]
write_annotations_api_key = [
  "z53trmxvqgz4d16gpzrgcnjwbsu7lkg2wzhxkejk",
  "s3celxuqku4ifn8clzr3z76gf8vb4xw6akih0b7g",
]