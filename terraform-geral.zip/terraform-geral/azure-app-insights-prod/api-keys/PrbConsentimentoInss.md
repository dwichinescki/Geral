## API Keys

- [0] - WebApi
- [1] - React

app_id = [
  "c3342022-4fe9-4fc6-81e6-e87495866c44",
  "5b7b03b4-0d69-4a72-a502-844d928fc28b",
]
authenticate_sdk_control_channel_api_key = [
  "j4m1fxu1cyv0vu5dtv7bz02kci10t7on81kf2r68",
  "icx7rlrr281nym0kcqdxezw6wfzqjf5ck16hgs7t",
]
full_permissions_api_key = [
  "opblpy72j8tbxd58u4hb17du3h7mjgfjr3cjtnxp",
  "727rapnj3uyjpwdi83rcujuebqb72p1zzm3j4swj",
]
instrumentation_key = [
  "43c64acd-eafa-4692-b3c6-56f4ed4b78ba",
  "884532f4-29ca-4b0a-ba6d-075ebc48814b",
]
read_telemetry_api_key = [
  "rb30o0kolu7mswfmc5ueeujjf3w1kj3mjntvu2w5",
  "25jhi8owkpgowsvngboshdbcz6tbg8veg5sexnft",
]
write_annotations_api_key = [
  "jhnaj3qrtis3mzzy1dl1ouooqlfrg6lhosy4k5nt",
  "hdfcr5i5qs7mmujacn40jruxwgchmrtp380j5v6p",
]