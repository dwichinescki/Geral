## API Keys

- [0] - WebApi
- [1] - React


app_id = [
  "017c8c37-2199-4d67-bc22-0ab42da0b74d",
  "c557dfcf-b39c-440b-8986-5d6f297f8ae4",
]
authenticate_sdk_control_channel_api_key = [
  "t3384b4vt7ldw7z2mnkdmmmbyoyuknj13vsukg3i",
  "1ls6y4ea783qe7e3fuvry1gqwcu6y1j58pevmwnl",
]
full_permissions_api_key = [
  "y0i18bnvk2tk2doh5n5q5fszf311tv4g0niw6ke3",
  "vx75zl4lwiv2gbujlohaa0hvpytobvk8ke6u2zgj",
]
instrumentation_key = [
  "971e24b7-5a88-4045-bffb-9da83553cb0e",
  "e8e62577-e948-4e2a-9b2c-ed33a0a27b11",
]
read_telemetry_api_key = [
  "wxe2zdyfx5eygvjd7zirs4jmnhqu0bto53sn83ns",
  "z6263o64fbj6lzq0pmlugfdhtmuquze6dbdfpi3s",
]
write_annotations_api_key = [
  "8kndhmb6v8dsxr1132gzq6o5c27w7jza0t8z7rql",
  "sve0t7gnbpfuf2l6vbbjn8yd5kfc6f32sjwlmbw7",
]