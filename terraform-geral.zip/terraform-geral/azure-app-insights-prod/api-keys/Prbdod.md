## API Keys

- [0] - WebApi
- [1] - React

App ID
```
app_id = [
  "5207f199-70d5-4c7d-a265-820d9cff4844",
]
```

Instrumentation Key
```
instrumentation_key = [
  "436d04f4-0c41-4707-a84b-15efa32636e2"
]
```

authenticate sdk Control Channel Api Key
```
authenticate_sdk_control_channel_api_key = [
  "ecxf0vyk44lced6j053ejujrsalh383ghi6cm6e5",
]
```

Full Permission Api Key
```
full_permissions_api_key = [
  "7kmwjkv8is6sxnsatxcu77i6jzuqnolxm8bzg38g",
]
```

Read Telemetry Api Key
```
read_telemetry_api_key = [
  "j66w2hbn7kn6g8bpgxd8aq7zry6np5gjd257jnir",
]
```

Write Annotations Api Key
```
write_annotations_api_key = [
  "m2fh4yikibij6nvfjken4jeqf8zfpieqhqfud7pm",
]
```