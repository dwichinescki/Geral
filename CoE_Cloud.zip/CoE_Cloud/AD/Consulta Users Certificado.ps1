# Script para consulta de usuários com scripts já emitidos na CA

# Luiz Fernando - 26/05/2022
#   - Elaboração
# Luiz Fernando - 01/06/202
#   - Correção de duplicatas nos arrays
#   - Tratativa para que só sejam considerados os certificados emitidos para usuários contidos nos grupos de VPN
#   - Tratativa dos valores a serem impressos

# Limpa variáveis
# Clear-Variable -Name ("user", "users", "emitidos", "arquivo", "template", "prodEmitidos", "aemitir" )

# Declara arrays
$users = @()
$prodEmitidos = @()
$aemitir = @()

# Preenche o array com usuários de VPN
foreach ($user in (Get-ADGroupMember "Fortinet_SSLVPN_ADM_infra" | Get-ADUser | Where-Object {$_.Enabled -eq $true})) {
    $users += $user
}
 
foreach ($user in (Get-ADGroupMember "Fortinet_SSLVPN_Diretoria" | Get-ADUser | Where-Object {$_.Enabled -eq $true})) {
    $users += $user
}

foreach ($user in (Get-ADGroupMember "Fortinet_SSLVPN_Distrito" | Get-ADUser | Where-Object {$_.Enabled -eq $true})) {
    $users += $user
}

foreach ($user in (Get-ADGroupMember "Fortinet_SSLVPN_Contingencia" | Get-ADUser | Where-Object {$_.Enabled -eq $true})) {
    $users += $user
}

foreach ($user in (Get-ADGroupMember "Fortinet_SSLVPN_Pilotos" | Get-ADUser | Where-Object {$_.Enabled -eq $true})) {
    $users += $user
}

foreach ($user in (Get-ADGroupMember "Fortinet_SSLVPN_Suporte" | Get-ADUser | Where-Object {$_.Enabled -eq $true})) {
    $users += $user
}

# Carrega lista exportada da CA para comparação
if ($null -eq $emitidos) {

    # Se quiser deixar mais interativo
    #Write-Host -ForegroundColor Yellow "Informe o caminho completo do arquivo CSV: " -NoNewline
    #$arquivo = Read-Host

    # Ajuste Luiz
    $arquivo = "C:\users\luizfmm\Downloads\certificados2.csv"
    $emitidos =  Import-Csv $arquivo
}

# Nome do template do certificado na CA
$template = "VPNUser (1.3.6.1.4.1.311.21.8.6291771.2154002.4017321.5755195.145578.177.12809392.3546003)"

# Gera array com os certificados emitidos para o template da VPN
$emitidos = $emitidos | Where-Object {$_."Certificate Template" -eq $template}

# Preenche os dois arrays com a mesma estrutura para possibilitar comparação
$emitidos = $emitidos."Requester Name" -replace 'PARANABANCO\\', ''
$users = $users.SamAccountName

# Trata o array de emitidos para só conter usuários que sejam de VPN, ignorando os certificados emitidos como teste
foreach ($user in $emitidos) {
    if ($users -contains $user) {
    $prodEmitidos += $user
    }
}

# Preenche o array aemitir com os usuários que não estão contidos na lista de emitidos
foreach ($user in $users) {
    if ($emitidos -notcontains $user) {
        $aemitir += $user
    }
}

# Limpa duplicatas nos arrays
$prodEmitidos = $prodEmitidos | Sort-Object -Unique
$aemitir = $aemitir | Sort-Object -Unique
$users = $users | Sort-Object -Unique


# Imprime resultado
Write-Host -ForegroundColor Yellow "Usuarios ativos: " $users.Count `n"Certificados emitidos: " $prodEmitidos.Count `n"Certificados a emitir: " $aemitir.Count
