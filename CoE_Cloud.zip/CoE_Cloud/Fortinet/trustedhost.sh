#! /bin/bash


echo config system admin
sleep 1
echo edit "luizfmm"
sleep 1
echo set trusthost1 10.0.0.0 255.0.0.0
sleep 1
echo set trusthost2 187.73.112.1 255.255.255.255
sleep 1
echo end

echo config system admin
sleep 1
echo edit "augustocr"
sleep 1
echo set trusthost1 10.0.0.0 255.0.0.0
sleep 1
echo set trusthost2 187.73.112.1 255.255.255.255
sleep 1
echo end

echo config system admin
sleep 1
echo edit "andredsa"
sleep 1
echo set trusthost1 10.0.0.0 255.0.0.0
sleep 1
echo set trusthost2 187.73.112.1 255.255.255.255
sleep 1
echo end
echo end
echo quit
