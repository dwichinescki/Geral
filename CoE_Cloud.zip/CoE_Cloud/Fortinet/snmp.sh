#! /bin/bash

echo config system snmp community
echo edit 1
echo set name "89kjkljasdlkj"
echo config hosts
echo edit 1
echo set ip 10.160.5.10 255.255.255.255
echo next
echo edit 2
echo set ip 10.160.5.4 255.255.255.255
echo next
echo end
echo end
echo quit
