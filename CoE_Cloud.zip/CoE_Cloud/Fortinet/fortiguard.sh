#!/bin/bash

echo 'get sys status | grep Serial'
sleep 1
echo 'get sys fortiguard | grep outbreak-prevention-license'
sleep 1

echo quit
