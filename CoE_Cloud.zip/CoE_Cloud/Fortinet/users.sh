#! /bin/bash

echo config system admin
sleep 1
echo delete luizfmm
sleep 1
echo delete augustocr
sleep 1
echo edit "willianr"
sleep 1
echo set remote-auth enable
sleep 1
echo set trusthost1 10.0.0.0 255.0.0.0
sleep 1
echo set accprofile "Leitura"
sleep 1
echo set vdom "root"
sleep 1
echo set remote-group "RadiusGroup-PRB"
sleep 1
echo next
sleep 1
echo end
sleep 1
echo quit